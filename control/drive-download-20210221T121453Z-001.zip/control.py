"""
Module that controls a heating of smart boiler. 

Uses module Bojler for computing time needed to heating of water, 
module TimeHandler for basic time and date operations, 
WeekPlanner for plan week heating, 
SettingsLoader to load setting from settings file and EventChecker which checks events in calendar, 
when the water shouldnt be heated.

"""

from datetime import datetime, timedelta
import pandas as pd
import matplotlib.pyplot as plot
import calendar 
from influxdb import DataFrameClient
from influxdb import InfluxDBClient
import os.path
import signal
import sys

import time
import json
import requests



from scipy.misc import electrocardiogram
import numpy as np


from bojler import Bojler
from time_handler import TimeHandler
from week_planner import WeekPlanner
from settings_loader import SettingLoader
from event_checker import EventChecker
#################################################
#######################TODO######################
#################################################
#jednou za 14 dni ohrat pred odberem na max

class Controller:
    """Main and only class which decides about heating
    """


    def __init__(self, db_name,socket_url, tmp_output = 'tmp1', tmp_bojler = 'tmp2', host = 'influxdb', port = 8086, bojler_capacity = 100, bojler_wattage = 2000):
        """Initializes controller with settings from SettingsLoader

        Args:
            db_name ([type]): [description]
            socket_url ([type]): [description]
            tmp_output (str, optional): [description]. Defaults to 'tmp1'.
            tmp_bojler (str, optional): [description]. Defaults to 'tmp2'.
            host (str, optional): [description]. Defaults to 'influxdb'.
            port (int, optional): [description]. Defaults to 8086.
            bojler_capacity (int, optional): [description]. Defaults to 100.
            bojler_wattage (int, optional): [description]. Defaults to 2000.
        """
        self.heating_coef = 1.5
        self.tmp_min = 32
        self.consumption_tmp_min = 36

        self.tmp_output = tmp_output
        self.tmp_bojler = tmp_bojler

        self.db_name = db_name

        self.data_db = self._actualize_data()
        self.last_data_update = datetime.datetime.now() 
        self.WeekPlanner = WeekPlanner(self.data_db)

        self.InfluxDBClient = InfluxDBClient(host, port, retries=5, timeout=1)
        self.DataFrameClient = DataFrameClient(host=host, database=self.db_name)

        self.socket_url = socket_url

        self.EventChecker = EventChecker()
        self.TimeHandler = TimeHandler()
        self.Bojler = Bojler(bojler_capacity, bojler_wattage)

    def _last_entry(self, measurement = 'senzory_bojler'):
        """Loads last entru from DB - actual.

        Args:
            measurement (str, optional): [description]. Defaults to 'senzory_bojler'.

        Returns:
            [type]: [last entry values]
        """
        #dodelat kontrolu stari zaznamu. pri prilis starem ohriva
        try:
            result = self.InfluxDBClient.query('SELECT * FROM "' + self.db_name + '"."autogen"."' + measurement + '" ORDER BY DESC LIMIT 1')

            tmp1 = result.raw['series'][0]['values'][0][2]
            tmp2 = result.raw['series'][0]['values'][0][3]
            socket_turned_on = result.raw['series'][0]['values'][0][4]

            return (tmp1, tmp2, socket_turned_on)
        except:
            return None




    def _actualize_data(self, measurement ='senzory_bojler', host = 'influx_db'):
        """

        Args:
            measurement (str, optional): [description]. Defaults to 'senzory_bojler'.
            host (str, optional): [description]. Defaults to 'influx_db'.

        Returns:
            [type]: Returns data from DB
        """


        try:
            datasets = self.DataFrameClient.query('SELECT mean('+ self.tmp_output + ') FROM "' + self.db_name + '"."autogen"."' + measurement + '"  group by time(1m) ORDER BY DESC')[measurement]
            #fill(previous)
            print("got new datasets")
        
            return pd.DataFrame(datasets.mean_tmp)
        except:
            print("it wasnt posiible to get new datasets")
        return None

    def _next_heating_time(self, event):

        """Finds how long it takes to next heating.

        Returns:
            [type]: [description]
        """
        actual_time = self.TimeHandler.hour_minutes_now()


        days_plus = 0

        while(1):
        
            day_plan = self.WeekPlanner.week_days_consumptions[self.TimeHandler.this_day_string(days_plus)]

            for  key, item in   day_plan.items():
                next_time = item[event]

                if (next_time >= actual_time):

                    return [(next_time - actual_time + timedelta(days = days_plus)) / timedelta(hours=1), item['duration'], item['peak']]


            actual_time = self.TimeHandler.hour_minutes_now().replace(hour=0, minute=0)
            days_plus += 1
                
    def _is_in_heating(self):

        hours_to_end = self._next_heating_time('end')[0]
        hours_to_start = self._next_heating_time('start')[0]

        return hours_to_start > hours_to_end

    def _check_data(self):
        if self.last_data_update - datetime.now() > timedelta(days = 7):
            print(datetime.now())
            print("actualizing data")

            actualized_data = self._actualize_data() 
            if actualized_data is not None:
                self.data_db = actualized_data
                self.WeekPlanner.week_plan(self.data_db)

    def control(self):

        self._check_data()

        tmp_out, tmp_act, is_on = self._last_entry()


        #or is in consumption and temperature is below smthing

        #if(self.is_in_heating and tmp_act < self.consumption_tmp_min):
            #pokud dojdu sem, je potreba zvetsit teplotu ohrevu. pokud to jiz nejde, zvetsit min (pouze jen do nejake hodnoty)

        time_to_consumption = self._next_heating_time('start')[0]
        tmp_goal = self._heating_temperature()

        if self.EventChecker.check_event():
            if is_on:
                self._turn_socket_off()
            return

        if (tmp_act < self.tmp_min):
            if not is_on:
                self._turn_socket_on()
            return
        if( self.Bojler.is_needed_to_heat(tmp_act, tmp_goal=tmp_goal, time_to_consumption = time_to_consumption)):
            if not is_on:
                self._turn_socket_on()
            return


        #rozlisovat cas do dalsiho topeni. pokud prave skoncilo, tolik nevadi     
        if (self._is_in_heating() and tmp_act < self.consumption_tmp_min):
            self.heating_coef *= 1.1
            if not is_on:
                self._turn_socket_on()
            return    

        if((not self._is_in_heating()) and (tmp_act > (self.consumption_tmp_min + 2))):
            self.heating_coef *= 0.9
            
        if is_on:
                self._turn_socket_off()

    def _turn_socket_on(self):
        try:
            requests.get("http://" + self.socket_url +"/relay/0?turn=on")   
        except:
            print(datetime.now())
            print("it was unable to turn on socket")       

    def _turn_socket_off(self):
        try:
            requests.get("http://" + self.socket_url +"/relay/0?turn=off")
        except:
            print(datetime.now())
            print("it was unable to turn off socket")        


    def _heating_temperature(self):

        if(self._is_in_heating()):
            heating = self._next_heating_time('end')
        else:
            heating = self._next_heating_time('start')

        peak = heating[2]

        return self.heating_coef * peak
  
  


if __name__ == '__main__':

    import sys
    
    from optparse import OptionParser
    parser = OptionParser('%prog [OPTIONS] <host> <port>')
    
    parser.add_option(
        '-f', '--settings_file', dest='settings_file',
        type='string', 
        default=None
        )
    options, args = parser.parse_args()

    settings_file = options.settings_file


    #data = pd.read_pickle('data.pkl')


    SettingsLoader = SettingsLoader(settings_file)
    settings = SettingsLoader.load_settings()

    
    db_name = settings['db_name']
    host = settings['db_host']
    port = settings['db_port']

    measurement = settings['measurement']
    
    socket_url = settings['socket_url']

    tmp_output = settings['tmp_output']
    tmp_bojler = settings['tmp_bojler']

    bojler_wattage = settings['bojler_wattage']
    bojler_capacity = settings['bojler_capacity']


    c = Controller(host = host, port = port, socket_url = socket_url,db_name = db_name, tmp_output = tmp_output, tmp_bojler = tmp_bojler, bojler_wattage = bojler_wattage, bojler_capacity = bojler_capacity)

    while (1):
        try:
            c.control()
        except:
            print(datetime.now())
            print("unable to control in this cycle")
        time.sleep(120)
    




